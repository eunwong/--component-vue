<template>
  <div style="padding: 50px 80px 30px 40px; width: 100vw; height: 100vh">
    <BaseTableCURD
      :config="config1"
      :data="data"
      :tableData="{
        loading,
        data,
        pagination,
      }"
      @submit="formSubmit"
      @paging="pagingLoad"
      @search="searchLoad"
    >
      <template #handleArea>
        <a-button data-action="from" data-from="a" type="primary"
          >Primary Button</a-button
        >
        <a-button data-action="del"> Default Button</a-button>
      </template>
      <template #T-HANDLER="{ row, rowIndex }"> </template>
    </BaseTableCURD>
  </div>
</template>
<script setup>
import BaseTableCURD from "@/components/QTable/BaseTableCURD.vue";
import { config } from "./config.js";
import { ref } from "vue";
import { Yl0CustomQueryAgent } from "@/api/index.js";
import { useTable } from "./useTable.js";
import { useForm } from "./useForm.js";
const config1 = ref(config());

const { data, loading, pagination, pagingLoad, searchLoad } = useTable(
  Yl0CustomQueryAgent,
  {
    className: "Yl0BranchFactoryStatisticRate",
    queryArgs: {
      attrSet: ["*"],
      condition: [
        { key: "yl0factory", compare: "like" },
        { key: "yl0equCode", compare: "like" },
        { key: "yl0equName", compare: "like" },
        { key: "yl0year", compare: "eq" },
        { key: "yl0monthly", compare: "eq" },
        { key: "yl0daily", compare: "eq" },
        { key: "yl0belongProject", compare: "eq" },
      ],
      page: { pageSize: "${pageSize}", pageNo: "${pageNo}" },
      sort: { sortBy: "createAt", sortOrder: "desc" },
    },
  }
);
const { formSubmit } = useForm(pagingLoad);
</script>
<style lang="less" scoped></style>

<!-- const exampleObj = {
  className: "Yl0BranchFactoryStatisticRate",
  queryArgs: {
      condition: [
          { key: "yl0factory", value: "#{searchValue}" },
          { key: "yl0equCode", compare: "like" },
          { key: "yl0equName", compare: "like" },
          "#{searchParams}",
      ],
      page: { pageSize: "${pageSize}", pageNo: "${pageNo}" },
      sort: { sortBy: "createAt", sortOrder: "desc" },
  },
};

const aaa = {
  searchValue: { value: "YL003", compare: "like" },
  searchParams: [
      { key: "yl0year", value: "2024", compare: "eq" },
      { key: "yl0monthly", value: "07", compare: "eq" },
      { key: "yl0daily", compare: "eq" },
      { key: "yl0belongProject", compare: "eq" },
  ],
  pageNo: 1,
  pageSize: 15,
}; 


{
  "className": "Yl0BranchFactoryStatisticRate",
  "queryArgs": {
    "condition": [
      {"key": "yl0factory","value": "YL003","compare": "like"},
      {"key": "yl0equCode","compare": "like"},
      {"key": "yl0equName","compare": "like"},
      {"key": "yl0year","value": "2024","compare": "eq"},
      {"key": "yl0monthly","value": "07","compare": "eq"},
      {"key": "yl0daily", "compare": "eq"},
      {"key": "yl0belongProject","compare": "eq"}
    ],
    "page": {"pageSize": 15,"pageNo": 1
    },
    "sort": {"sortBy": "createAt", "sortOrder": "desc"
    }
  }
}
-->
